package com.collector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
